/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xc3576ebc */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "I:/vhdl/catch/catch2114.vhd";



static void work_a_0417539320_3212880686_p_0(char *t0)
{
    char *t1;
    char *t2;
    int t3;
    int t4;
    char *t5;
    char *t6;
    int t7;
    int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    char *t12;
    unsigned char t13;
    unsigned char t14;
    char *t15;
    char *t16;
    int t17;
    char *t18;
    int t19;
    int t20;
    char *t21;
    unsigned char t22;
    unsigned char t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned char t27;
    char *t28;
    char *t29;
    unsigned int t30;
    unsigned int t31;
    unsigned int t32;

LAB0:    xsi_set_current_line(53, ng0);
    t1 = (t0 + 2368U);
    t2 = *((char **)t1);
    t1 = (t2 + 0);
    *((int *)t1) = 0;
    xsi_set_current_line(54, ng0);
    t1 = (t0 + 2488U);
    t2 = *((char **)t1);
    t1 = (t2 + 0);
    *((int *)t1) = 0;
    xsi_set_current_line(55, ng0);
    t1 = (t0 + 10564);
    *((int *)t1) = 8;
    t2 = (t0 + 10568);
    *((int *)t2) = 3;
    t3 = 8;
    t4 = 3;

LAB2:    if (t3 >= t4)
        goto LAB3;

LAB5:    xsi_set_current_line(61, ng0);
    t1 = (t0 + 10572);
    *((int *)t1) = 2;
    t2 = (t0 + 10576);
    *((int *)t2) = 0;
    t3 = 2;
    t4 = 0;

LAB10:    if (t3 >= t4)
        goto LAB11;

LAB13:    xsi_set_current_line(67, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t3 = (9 - 9);
    t9 = (t3 * -1);
    t10 = (1U * t9);
    t11 = (0 + t10);
    t1 = (t2 + t11);
    t13 = *((unsigned char *)t1);
    t14 = (t13 == (unsigned char)3);
    if (t14 != 0)
        goto LAB18;

LAB20:
LAB19:    xsi_set_current_line(70, ng0);
    t1 = (t0 + 1192U);
    t2 = *((char **)t1);
    t13 = *((unsigned char *)t2);
    t14 = (t13 == (unsigned char)2);
    if (t14 != 0)
        goto LAB21;

LAB23:    t1 = (t0 + 1192U);
    t2 = *((char **)t1);
    t13 = *((unsigned char *)t2);
    t14 = (t13 == (unsigned char)3);
    if (t14 != 0)
        goto LAB29;

LAB30:
LAB22:    t1 = (t0 + 4032);
    *((int *)t1) = 1;

LAB1:    return;
LAB3:    xsi_set_current_line(56, ng0);
    t5 = (t0 + 1032U);
    t6 = *((char **)t5);
    t5 = (t0 + 10564);
    t7 = *((int *)t5);
    t8 = (t7 - 9);
    t9 = (t8 * -1);
    xsi_vhdl_check_range_of_index(9, 0, -1, *((int *)t5));
    t10 = (1U * t9);
    t11 = (0 + t10);
    t12 = (t6 + t11);
    t13 = *((unsigned char *)t12);
    t14 = (t13 == (unsigned char)3);
    if (t14 != 0)
        goto LAB6;

LAB8:
LAB7:    xsi_set_current_line(59, ng0);
    t1 = (t0 + 2608U);
    t2 = *((char **)t1);
    t7 = *((int *)t2);
    t8 = (t7 * 2);
    t1 = (t0 + 2608U);
    t5 = *((char **)t1);
    t1 = (t5 + 0);
    *((int *)t1) = t8;

LAB4:    t1 = (t0 + 10564);
    t3 = *((int *)t1);
    t2 = (t0 + 10568);
    t4 = *((int *)t2);
    if (t3 == t4)
        goto LAB5;

LAB9:    t7 = (t3 + -1);
    t3 = t7;
    t5 = (t0 + 10564);
    *((int *)t5) = t3;
    goto LAB2;

LAB6:    xsi_set_current_line(57, ng0);
    t15 = (t0 + 2368U);
    t16 = *((char **)t15);
    t17 = *((int *)t16);
    t15 = (t0 + 2608U);
    t18 = *((char **)t15);
    t19 = *((int *)t18);
    t20 = (t17 + t19);
    t15 = (t0 + 2368U);
    t21 = *((char **)t15);
    t15 = (t21 + 0);
    *((int *)t15) = t20;
    goto LAB7;

LAB11:    xsi_set_current_line(62, ng0);
    t5 = (t0 + 1032U);
    t6 = *((char **)t5);
    t5 = (t0 + 10572);
    t7 = *((int *)t5);
    t8 = (t7 - 9);
    t9 = (t8 * -1);
    xsi_vhdl_check_range_of_index(9, 0, -1, *((int *)t5));
    t10 = (1U * t9);
    t11 = (0 + t10);
    t12 = (t6 + t11);
    t13 = *((unsigned char *)t12);
    t14 = (t13 == (unsigned char)3);
    if (t14 != 0)
        goto LAB14;

LAB16:
LAB15:    xsi_set_current_line(65, ng0);
    t1 = (t0 + 2728U);
    t2 = *((char **)t1);
    t7 = *((int *)t2);
    t8 = (t7 * 2);
    t1 = (t0 + 2728U);
    t5 = *((char **)t1);
    t1 = (t5 + 0);
    *((int *)t1) = t8;

LAB12:    t1 = (t0 + 10572);
    t3 = *((int *)t1);
    t2 = (t0 + 10576);
    t4 = *((int *)t2);
    if (t3 == t4)
        goto LAB13;

LAB17:    t7 = (t3 + -1);
    t3 = t7;
    t5 = (t0 + 10572);
    *((int *)t5) = t3;
    goto LAB10;

LAB14:    xsi_set_current_line(63, ng0);
    t15 = (t0 + 2488U);
    t16 = *((char **)t15);
    t17 = *((int *)t16);
    t15 = (t0 + 2728U);
    t18 = *((char **)t15);
    t19 = *((int *)t18);
    t20 = (t17 + t19);
    t15 = (t0 + 2488U);
    t21 = *((char **)t15);
    t15 = (t21 + 0);
    *((int *)t15) = t20;
    goto LAB15;

LAB18:    xsi_set_current_line(68, ng0);
    t5 = (t0 + 2488U);
    t6 = *((char **)t5);
    t4 = *((int *)t6);
    t7 = (t4 + 8);
    t5 = (t0 + 2488U);
    t12 = *((char **)t5);
    t5 = (t12 + 0);
    *((int *)t5) = t7;
    goto LAB19;

LAB21:    xsi_set_current_line(72, ng0);
    t1 = (t0 + 1352U);
    t5 = *((char **)t1);
    t22 = *((unsigned char *)t5);
    t23 = (t22 == (unsigned char)3);
    if (t23 != 0)
        goto LAB24;

LAB26:    t1 = (t0 + 1352U);
    t2 = *((char **)t1);
    t13 = *((unsigned char *)t2);
    t14 = (t13 == (unsigned char)2);
    if (t14 != 0)
        goto LAB27;

LAB28:
LAB25:    goto LAB22;

LAB24:    xsi_set_current_line(73, ng0);
    t1 = (t0 + 1832U);
    t6 = *((char **)t1);
    t1 = (t0 + 2488U);
    t12 = *((char **)t1);
    t3 = *((int *)t12);
    t4 = (16 * 3);
    t7 = (t3 + t4);
    t8 = (t7 - 63);
    t9 = (t8 * -1);
    xsi_vhdl_check_range_of_index(63, 0, -1, t7);
    t10 = (1U * t9);
    t1 = (t0 + 2368U);
    t15 = *((char **)t1);
    t17 = *((int *)t15);
    t19 = (t17 - 63);
    t11 = (t19 * -1);
    xsi_vhdl_check_range_of_index(63, 0, -1, t17);
    t24 = (64U * t11);
    t25 = (0 + t24);
    t26 = (t25 + t10);
    t1 = (t6 + t26);
    t27 = *((unsigned char *)t1);
    t16 = (t0 + 4112);
    t18 = (t16 + 56U);
    t21 = *((char **)t18);
    t28 = (t21 + 56U);
    t29 = *((char **)t28);
    *((unsigned char *)t29) = t27;
    xsi_driver_first_trans_delta(t16, 0U, 1, 0LL);
    xsi_set_current_line(74, ng0);
    t1 = (t0 + 1832U);
    t2 = *((char **)t1);
    t1 = (t0 + 2488U);
    t5 = *((char **)t1);
    t3 = *((int *)t5);
    t4 = (16 * 2);
    t7 = (t3 + t4);
    t8 = (t7 - 63);
    t9 = (t8 * -1);
    xsi_vhdl_check_range_of_index(63, 0, -1, t7);
    t10 = (1U * t9);
    t1 = (t0 + 2368U);
    t6 = *((char **)t1);
    t17 = *((int *)t6);
    t19 = (t17 - 63);
    t11 = (t19 * -1);
    xsi_vhdl_check_range_of_index(63, 0, -1, t17);
    t24 = (64U * t11);
    t25 = (0 + t24);
    t26 = (t25 + t10);
    t1 = (t2 + t26);
    t13 = *((unsigned char *)t1);
    t12 = (t0 + 4112);
    t15 = (t12 + 56U);
    t16 = *((char **)t15);
    t18 = (t16 + 56U);
    t21 = *((char **)t18);
    *((unsigned char *)t21) = t13;
    xsi_driver_first_trans_delta(t12, 1U, 1, 0LL);
    xsi_set_current_line(75, ng0);
    t1 = (t0 + 1832U);
    t2 = *((char **)t1);
    t1 = (t0 + 2488U);
    t5 = *((char **)t1);
    t3 = *((int *)t5);
    t4 = (t3 + 16);
    t7 = (t4 - 63);
    t9 = (t7 * -1);
    xsi_vhdl_check_range_of_index(63, 0, -1, t4);
    t10 = (1U * t9);
    t1 = (t0 + 2368U);
    t6 = *((char **)t1);
    t8 = *((int *)t6);
    t17 = (t8 - 63);
    t11 = (t17 * -1);
    xsi_vhdl_check_range_of_index(63, 0, -1, t8);
    t24 = (64U * t11);
    t25 = (0 + t24);
    t26 = (t25 + t10);
    t1 = (t2 + t26);
    t13 = *((unsigned char *)t1);
    t12 = (t0 + 4112);
    t15 = (t12 + 56U);
    t16 = *((char **)t15);
    t18 = (t16 + 56U);
    t21 = *((char **)t18);
    *((unsigned char *)t21) = t13;
    xsi_driver_first_trans_delta(t12, 2U, 1, 0LL);
    xsi_set_current_line(76, ng0);
    t1 = (t0 + 1832U);
    t2 = *((char **)t1);
    t1 = (t0 + 2488U);
    t5 = *((char **)t1);
    t3 = *((int *)t5);
    t4 = (t3 - 63);
    t9 = (t4 * -1);
    xsi_vhdl_check_range_of_index(63, 0, -1, t3);
    t10 = (1U * t9);
    t1 = (t0 + 2368U);
    t6 = *((char **)t1);
    t7 = *((int *)t6);
    t8 = (t7 - 63);
    t11 = (t8 * -1);
    xsi_vhdl_check_range_of_index(63, 0, -1, t7);
    t24 = (64U * t11);
    t25 = (0 + t24);
    t26 = (t25 + t10);
    t1 = (t2 + t26);
    t13 = *((unsigned char *)t1);
    t12 = (t0 + 4112);
    t15 = (t12 + 56U);
    t16 = *((char **)t15);
    t18 = (t16 + 56U);
    t21 = *((char **)t18);
    *((unsigned char *)t21) = t13;
    xsi_driver_first_trans_delta(t12, 3U, 1, 0LL);
    goto LAB25;

LAB27:    xsi_set_current_line(79, ng0);
    t1 = (t0 + 1672U);
    t5 = *((char **)t1);
    t3 = (3 - 3);
    t9 = (t3 * -1);
    t10 = (1U * t9);
    t11 = (0 + t10);
    t1 = (t5 + t11);
    t22 = *((unsigned char *)t1);
    t6 = (t0 + 2368U);
    t12 = *((char **)t6);
    t4 = *((int *)t12);
    t7 = (t4 - 63);
    t24 = (t7 * -1);
    t25 = (64U * t24);
    t26 = (0U + t25);
    t6 = (t0 + 2488U);
    t15 = *((char **)t6);
    t8 = *((int *)t15);
    t17 = (16 * 3);
    t19 = (t8 + t17);
    t20 = (t19 - 63);
    t30 = (t20 * -1);
    t31 = (1 * t30);
    t32 = (t26 + t31);
    t6 = (t0 + 4176);
    t16 = (t6 + 56U);
    t18 = *((char **)t16);
    t21 = (t18 + 56U);
    t28 = *((char **)t21);
    *((unsigned char *)t28) = t22;
    xsi_driver_first_trans_delta(t6, t32, 1, 0LL);
    xsi_set_current_line(80, ng0);
    t1 = (t0 + 1672U);
    t2 = *((char **)t1);
    t3 = (2 - 3);
    t9 = (t3 * -1);
    t10 = (1U * t9);
    t11 = (0 + t10);
    t1 = (t2 + t11);
    t13 = *((unsigned char *)t1);
    t5 = (t0 + 2368U);
    t6 = *((char **)t5);
    t4 = *((int *)t6);
    t7 = (t4 - 63);
    t24 = (t7 * -1);
    t25 = (64U * t24);
    t26 = (0U + t25);
    t5 = (t0 + 2488U);
    t12 = *((char **)t5);
    t8 = *((int *)t12);
    t17 = (16 * 2);
    t19 = (t8 + t17);
    t20 = (t19 - 63);
    t30 = (t20 * -1);
    t31 = (1 * t30);
    t32 = (t26 + t31);
    t5 = (t0 + 4176);
    t15 = (t5 + 56U);
    t16 = *((char **)t15);
    t18 = (t16 + 56U);
    t21 = *((char **)t18);
    *((unsigned char *)t21) = t13;
    xsi_driver_first_trans_delta(t5, t32, 1, 0LL);
    xsi_set_current_line(81, ng0);
    t1 = (t0 + 1672U);
    t2 = *((char **)t1);
    t3 = (1 - 3);
    t9 = (t3 * -1);
    t10 = (1U * t9);
    t11 = (0 + t10);
    t1 = (t2 + t11);
    t13 = *((unsigned char *)t1);
    t5 = (t0 + 2368U);
    t6 = *((char **)t5);
    t4 = *((int *)t6);
    t7 = (t4 - 63);
    t24 = (t7 * -1);
    t25 = (64U * t24);
    t26 = (0U + t25);
    t5 = (t0 + 2488U);
    t12 = *((char **)t5);
    t8 = *((int *)t12);
    t17 = (16 * 1);
    t19 = (t8 + t17);
    t20 = (t19 - 63);
    t30 = (t20 * -1);
    t31 = (1 * t30);
    t32 = (t26 + t31);
    t5 = (t0 + 4176);
    t15 = (t5 + 56U);
    t16 = *((char **)t15);
    t18 = (t16 + 56U);
    t21 = *((char **)t18);
    *((unsigned char *)t21) = t13;
    xsi_driver_first_trans_delta(t5, t32, 1, 0LL);
    xsi_set_current_line(82, ng0);
    t1 = (t0 + 1672U);
    t2 = *((char **)t1);
    t3 = (0 - 3);
    t9 = (t3 * -1);
    t10 = (1U * t9);
    t11 = (0 + t10);
    t1 = (t2 + t11);
    t13 = *((unsigned char *)t1);
    t5 = (t0 + 2368U);
    t6 = *((char **)t5);
    t4 = *((int *)t6);
    t7 = (t4 - 63);
    t24 = (t7 * -1);
    t25 = (64U * t24);
    t26 = (0U + t25);
    t5 = (t0 + 2488U);
    t12 = *((char **)t5);
    t8 = *((int *)t12);
    t17 = (t8 - 63);
    t30 = (t17 * -1);
    t31 = (1 * t30);
    t32 = (t26 + t31);
    t5 = (t0 + 4176);
    t15 = (t5 + 56U);
    t16 = *((char **)t15);
    t18 = (t16 + 56U);
    t21 = *((char **)t18);
    *((unsigned char *)t21) = t13;
    xsi_driver_first_trans_delta(t5, t32, 1, 0LL);
    goto LAB25;

LAB29:    xsi_set_current_line(85, ng0);
    t1 = (t0 + 10580);
    t6 = (t0 + 4112);
    t12 = (t6 + 56U);
    t15 = *((char **)t12);
    t16 = (t15 + 56U);
    t18 = *((char **)t16);
    memcpy(t18, t1, 4U);
    xsi_driver_first_trans_fast_port(t6);
    goto LAB22;

}


extern void work_a_0417539320_3212880686_init()
{
	static char *pe[] = {(void *)work_a_0417539320_3212880686_p_0};
	xsi_register_didat("work_a_0417539320_3212880686", "isim/catch2114_tb_isim_beh.exe.sim/work/a_0417539320_3212880686.didat");
	xsi_register_executes(pe);
}
